/*:
 # Chapter 6 Structs
 * [01 Create Structs](01CreateStructs)
 * [02 Stored Properties](02StoredProperties)
 * [03 Computed Properties](03ComputedProperties)
 * [04 willSet didSet](04WillSetDidSet)
 * [05 CustomStringConvertible](05CustomStringConvertible)
 * [06 Equatable](06Equatable)
 * [07 Value Types](07ValueTypes)
 * [08 Methods](08Methods)
 * [09 Custom Operators](09CustomOperators)
 */

