//: ### Computed Properties
//: [TOC](00TOC) | [Previous](@previous) | [Next](@next)
struct Vertex {
  let x, y: Double
}

let point = Vertex(x: 3.0, y: 4.0)
//: [TOC](00TOC) | [Previous](@previous) | [Next](@next)



