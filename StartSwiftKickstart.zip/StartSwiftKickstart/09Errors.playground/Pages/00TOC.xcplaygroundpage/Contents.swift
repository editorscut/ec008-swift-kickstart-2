/*:
 # Chapter 9 Errors
 * [01 Examples](01Examples)
 * [02 Optionals](02Optionals)
 * [03 Asserts](03Asserts)
 * [04 Throwing Errors](04ThrowingErrors)
 * [05 Catching Errors](05CatchingErrors)
 * [06 Defer](06Defer)
 * [07 Structs](07Structs)
 * [08 Enumerations](08Enumerations)
 * [09 Multiple Catches](09MultipleCatches)
 * [10 Rethrows](10Rethrows)
 * [11 Result](11Result)
 */

