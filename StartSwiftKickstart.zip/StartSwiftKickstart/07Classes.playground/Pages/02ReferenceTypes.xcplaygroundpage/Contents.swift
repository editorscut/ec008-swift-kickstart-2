//: ### Reference Types
//: [TOC](00TOC) | [Previous](@previous) | [Next](@next)
class Attendee {
  let name = "Daniel"
  let hometown = "Shaker Heights"
}

let person1 = Attendee()
person1.name
person1.hometown
//: [TOC](00TOC) | [Previous](@previous) | [Next](@next)

