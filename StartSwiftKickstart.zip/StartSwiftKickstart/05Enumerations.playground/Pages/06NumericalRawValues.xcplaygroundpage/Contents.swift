//: ### Numerical Raw Values
//: [TOC](00TOC) | [Previous](@previous) | [Next](@next)
enum PrimaryColor {
    case red
    case yellow
    case blue
}

//: [TOC](00TOC) | [Previous](@previous) | [Next](@next)

