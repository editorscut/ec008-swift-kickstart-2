//#-hidden-code
import UIKit
//#-end-hidden-code

var str = "Hello, playground"
