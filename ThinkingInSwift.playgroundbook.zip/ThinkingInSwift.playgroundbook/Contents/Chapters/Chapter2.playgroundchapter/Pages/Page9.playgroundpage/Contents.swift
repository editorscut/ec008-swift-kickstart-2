func hello(name: String) -> String {
    return "Hello, \(name)!"
}
hello(name: "my friend")