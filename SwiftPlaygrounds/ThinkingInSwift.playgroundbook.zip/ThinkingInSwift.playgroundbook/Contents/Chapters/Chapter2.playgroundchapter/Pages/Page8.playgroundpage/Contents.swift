let name = "Swift Programmer"
print("Hello, World!")
print("Hello, \(name)!")
print("Hello,", name, "!")
print("Hello,", name, "!", separator:"^-^")
print("Hello, ", name, "!", separator: "", terminator: "")