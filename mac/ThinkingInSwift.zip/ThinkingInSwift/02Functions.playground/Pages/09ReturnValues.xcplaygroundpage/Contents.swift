//: ### Return Values
//: [TOC](TOC) | [Previous](@previous) | [Next](@next)
func hello(name: String) -> String {
    return "Hello, \(name)!"
}
hello(name: "my friend")
//: [TOC](TOC) | [Previous](@previous) | [Next](@next)