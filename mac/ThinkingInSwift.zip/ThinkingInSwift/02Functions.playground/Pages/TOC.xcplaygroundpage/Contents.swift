/*:
 # Table of Contents
 * [01 No Parameter No Return](01NoParameterNoReturn)
 * [02 Single Parameter](02SingleParameter)
 * [03 Overloading](03Overloading)
 * [04 External Parameter Names](04ExternalParameterNames)
 * [05 Default Values](05DefaultValues)
 * [06 Multiple Parameters](06MultipleParameters)
 * [07 Variadic Parameters](07VariadicParameters)
 * [08 The print() Function](08ThePrintFunction)
 * [09 Return Values](09ReturnValues)
 * [10 Returning Tuples](10ReturningTuples)
 */