//: ### Optionals
//: [TOC](TOC) | [Previous](@previous) | [Next](@next)

extension Forecast {
    static func number(_ index: Int) -> String {
        return Forecast()[index]
    }
}

//: [TOC](TOC) | [Previous](@previous) | [Next](@next)
