//: ### Subscripts
//: [TOC](TOC) | Previous | [Next](@next)



//import Foundation
//
//
//setUp()
//
//let url = URL(string: "https://editorscut.com/")
//
//
//let task = URLSession.shared.dataTask(with: url!) { (data, response, error) in
//    print("response", response ?? "no response")
//    print(error ?? "no error")
//    shutDown()
//}
//
//task.resume()
//





//: [TOC](TOC) | Previous | [Next](@next)
