//: ### Optionals
//: [TOC](00TOC) | [Previous](@previous) | [Next](@next)
extension Forecast {
    static func number(_ index: Int) -> String {
        Forecast()[index]
    }
}

//: [TOC](00TOC) | [Previous](@previous) | [Next](@next)
