//: ### Stored Properties
//: [TOC](TOC) | [Previous](@previous) | [Next](@next)

struct Vertex {
}

let point = Vertex()
//: [TOC](TOC) | [Previous](@previous) | [Next](@next)
