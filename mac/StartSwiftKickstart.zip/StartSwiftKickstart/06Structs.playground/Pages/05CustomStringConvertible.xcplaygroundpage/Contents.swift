//: ### CustomStringConvertible
//: [TOC](TOC) | [Previous](@previous) | [Next](@next)
struct Vertex {
    let x, y: Double
}

let point = Vertex(x: 3, y: 4)

//: [TOC](TOC) | [Previous](@previous) | [Next](@next)
