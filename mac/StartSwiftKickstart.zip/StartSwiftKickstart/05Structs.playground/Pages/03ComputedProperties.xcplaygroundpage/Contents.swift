//: ### Computed Properties
//: [TOC](TOC) | [Previous](@previous) | [Next](@next)
struct Vertex {
    let x, y: Double
}

var point = Vertex(x: 3.0, y: 4.0)
//: [TOC](TOC) | [Previous](@previous) | [Next](@next)
