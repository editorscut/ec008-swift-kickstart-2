//: ### Initializers
//: [TOC](00TOC) | [Previous](@previous) | [Next](@next)
class Attendee {
    var name = "Daniel"
    let hometown = "Shaker Heights"
}
//: [TOC](00TOC) | [Previous](@previous) | [Next](@next)


