//: ### Initializers
//: [TOC](TOC) | [Previous](@previous) | [Next](@next)
class Attendee {
    var name = "Daniel"
    let hometown = "Shaker Heights"
}
//: [TOC](TOC) | [Previous](@previous) | [Next](@next)
