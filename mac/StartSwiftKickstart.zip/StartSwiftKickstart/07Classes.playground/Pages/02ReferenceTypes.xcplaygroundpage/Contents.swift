//: ### Reference Types
//: [TOC](TOC) | [Previous](@previous) | [Next](@next)
class Attendee {
    let name = "Daniel"
    let hometown = "Shaker Heights"
}

let person1 = Attendee()
person1.name
person1.hometown
//: [TOC](TOC) | [Previous](@previous) | [Next](@next)
