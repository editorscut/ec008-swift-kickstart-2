//: ### Let
//: [TOC](TOC) | [Previous](@previous) | [Next](@next)
let someone = "Swift Programmer"


//: [TOC](TOC) | [Previous](@previous) | [Next](@next)
