//: ### Let
//: [TOC](00TOC) | [Previous](@previous) | [Next](@next)
let someone = "Swift Programmer"

//: [TOC](00TOC) | [Previous](@previous) | [Next](@next)

