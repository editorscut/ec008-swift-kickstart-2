//: ### Nil Coalescing Operator
//: [TOC](TOC) | [Previous](@previous) | [Next](@next)
var name: String?
name = "Swifty"


//: [TOC](TOC) | [Previous](@previous) | [Next](@next)
