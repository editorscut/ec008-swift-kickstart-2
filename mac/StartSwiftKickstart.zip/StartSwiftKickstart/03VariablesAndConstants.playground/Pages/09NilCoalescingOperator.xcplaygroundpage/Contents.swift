//: ### Nil Coalescing Operator
//: [TOC](00TOC) | [Previous](@previous) | [Next](@next)

var name: String?
name = "Swifty"


//: [TOC](00TOC) | [Previous](@previous) | [Next](@next)

