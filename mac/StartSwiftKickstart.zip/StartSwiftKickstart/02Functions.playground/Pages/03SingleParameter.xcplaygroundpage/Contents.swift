//: ### Single Parameter
//: [TOC](TOC) | [Previous](@previous) | [Next](@next)
func hello() -> String {
    return "Hello, World!"
}

hello()
//: [TOC](TOC) | [Previous](@previous) | [Next](@next)
