//: ### Multiple Parameters
//: [TOC](00TOC) | [Previous](@previous) | [Next](@next)
func hello(name: String) -> String {
    return "Hello, \(name)!"
}
hello(name: "my friend")

//: [TOC](00TOC) | [Previous](@previous) | [Next](@next)
