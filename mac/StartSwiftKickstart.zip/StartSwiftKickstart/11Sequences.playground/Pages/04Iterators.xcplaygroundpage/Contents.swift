//: ### Iterators
//: [TOC](TOC) | [Previous](@previous) | [Next](@next)


enum Cardinal : Int {
    case zero
    case one
    case two
    case three
    case four
}



//: [TOC](TOC) | [Previous](@previous) | [Next](@next)
