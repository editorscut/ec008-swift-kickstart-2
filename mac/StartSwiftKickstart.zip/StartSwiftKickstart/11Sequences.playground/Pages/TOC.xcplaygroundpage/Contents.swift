/*:
 # Table of Contents
 * [01 Distributions](01Distributions)
 * [02 Raw Representable](02RawRepresentable)
 * [03 while let](03WhileLet)
 * [04 Iterators](04Iterators)
 * [05 Sequences](05Sequences)
 * [06 Sequence and Iterator](06SequenceAndIterator)
 * [07 Generic](07Generic)
 * [08 Subscripts](07Subscripts)
 */
