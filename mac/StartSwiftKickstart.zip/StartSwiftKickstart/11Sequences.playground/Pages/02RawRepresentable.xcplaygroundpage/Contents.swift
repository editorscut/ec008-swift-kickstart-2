//: ### Raw Representable
//: [TOC](00TOC) | [Previous](@previous) | [Next](@next)
enum Cardinal: Int {
    case zero
    case one
    case two
    case three
    case four
}

let number = Cardinal.three
//: [TOC](00TOC) | [Previous](@previous) | [Next](@next)
