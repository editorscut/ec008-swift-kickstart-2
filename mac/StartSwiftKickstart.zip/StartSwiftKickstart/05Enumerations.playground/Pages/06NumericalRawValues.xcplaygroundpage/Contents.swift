//: ### Numerical Raw Values
//: [TOC](00TOC) | [Previous](@previous) | [Next](@next)
enum Color {
    case red
    case green
    case blue
}

//: [TOC](00TOC) | [Previous](@previous) | [Next](@next)

