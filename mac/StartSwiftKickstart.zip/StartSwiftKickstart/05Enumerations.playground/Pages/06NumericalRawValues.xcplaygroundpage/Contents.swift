//: ### Numerical Raw Values
//: [TOC](TOC) | [Previous](@previous) | [Next](@next)
enum Color : String {
    case red
    case green
    case blue
}

//: [TOC](TOC) | [Previous](@previous) | [Next](@next)
