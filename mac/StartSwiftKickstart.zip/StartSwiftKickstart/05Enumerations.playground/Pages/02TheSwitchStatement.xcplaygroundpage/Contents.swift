//: ### The switch Statement
//: [TOC](TOC) | [Previous](@previous) | [Next](@next)
enum Color {
    case red
    case green
    case blue
}

//: [TOC](TOC) | [Previous](@previous) | [Next](@next)
