//: ### Associated Values
//: [TOC](TOC) | [Previous](@previous) | [Next](@next)

enum PrimaryColor {
    case red
    case yellow
    case blue
}

//: [TOC](TOC) | [Previous](@previous) | [Next](@next)
