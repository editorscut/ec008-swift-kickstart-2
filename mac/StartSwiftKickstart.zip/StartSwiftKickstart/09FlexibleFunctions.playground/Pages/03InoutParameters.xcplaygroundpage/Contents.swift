//: ### inout Parameters
//: [TOC](TOC) | [Previous](@previous) | [Next](@next)

var two = 2

func double(_ input: Int) {
    var input = input
    input = input * 2
}

double(two)
two

//: [TOC](TOC) | [Previous](@previous) | [Next](@next)
