/*:
 # Chapter 10 Flexible Functions
 * [01 Function Parameters](01FunctionParameters)
 * [02 Reference Types](02ReferenceTypes)
 * [03 inout Parameters](03InoutParameters)
 * [04 Return Values](04ReturnValues)
 * [05 Extensions](05Extensions)
 * [06 Mutable Model](06MutableModel)
 * [07 Non-Mutable Model](07NonMutableModel)
 * [08 Generics](08Generics)
 * [09 Conditional Conformance](09ConditionalConformance)
 */
