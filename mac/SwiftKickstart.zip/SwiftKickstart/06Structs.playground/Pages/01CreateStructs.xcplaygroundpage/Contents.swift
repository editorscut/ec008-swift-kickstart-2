//: ### Create Structs
//: [TOC](00TOC) | Previous | [Next](@next)
struct Vertex {
    
}

let point = Vertex()
//: [TOC](00TOC) | Previous | [Next](@next)

