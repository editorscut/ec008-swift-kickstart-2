//: ### Create Structs
//: [TOC](TOC) | Previous | [Next](@next)
struct Vertex {
    
}

let point = Vertex()


//: [TOC](TOC) | Previous | [Next](@next)
