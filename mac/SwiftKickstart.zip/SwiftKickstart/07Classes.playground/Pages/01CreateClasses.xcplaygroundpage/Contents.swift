//: ### Create Classes
//: [TOC](TOC) | Previous | [Next](@next)
class Attendee {
    let name = "Daniel"
    let hometown = "Shaker Heights"
}

let person1 = Attendee()
person1.name
person1.hometown


//: [TOC](TOC) | Previous | [Next](@next)
