//: ### Create Classes
//: [TOC](00TOC) | Previous | [Next](@next)

class Attendee {
  let name = "Daniel"
  let hometown = "Shaker Heights"
}

let person = Attendee()
person.name
person.hometown

//: [TOC](00TOC) | Previous | [Next](@next)


