//: ### The print() Function
//: [TOC](00TOC) | [Previous](@previous) | [Next](@next)

let name = "Swift Programmer"

print("Hello, \(name)!")
print("Hello,", name, "!")
print("Hello,", name, "!", separator:"^-^")
print("Hello, ", name, "!", separator:"", terminator: "")
print("Hello, ", name, separator:"", terminator: "!")


//: [TOC](00TOC) | [Previous](@previous) | [Next](@next)
