//: ### The print() Function
//: [TOC](TOC) | [Previous](@previous) | [Next](@next)
let name = "Swift Programmer"
print("Hello, World!")
print("Hello, \(name)!")
print("Hello,", name, "!")
print("Hello,", name, "!", separator:"^-^")
print("Hello, ", name, "!", separator: "", terminator: "")
//: [TOC](TOC) | [Previous](@previous) | [Next](@next)