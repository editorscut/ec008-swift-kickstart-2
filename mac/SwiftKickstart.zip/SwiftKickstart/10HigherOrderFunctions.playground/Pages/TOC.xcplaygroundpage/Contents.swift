/*:
 # Table of Contents
 * [01 Types](01Types)
 * [02 Returning a Function](02ReturningFunction)
 * [03 Returning a Closure](03ReturningAClosure)
 * [04 Consuming a Closure](04ConsumingAClosure)
 * [05 Mapping Arrays](05MappingArrays)
 * [06 Map](06Map)
 * [07 Filter](07Filter)
 * [08 Reduce](08Reduce)
 * [09 Flat Map](09FlatMap)
 */
