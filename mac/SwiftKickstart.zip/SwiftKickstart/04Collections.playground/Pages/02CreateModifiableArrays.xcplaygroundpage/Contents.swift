//: ### Create Modifiable Arrays
//: [TOC](00TOC) | [Previous](@previous) | [Next](@next)
var drinkSizes = ["Big", "Really Big", "Enormous"]
var sales = Array(repeating: 0, count: 3)
//: [TOC](00TOC) | [Previous](@previous) | [Next](@next)



