//: ### Create Modifiable Arrays
//: [TOC](TOC) | [Previous](@previous) | [Next](@next)

var drinkSizes = ["Big", "Really Big", "Huge"]
var sales = Array(repeating: 0, count: 3)

//: [TOC](TOC) | [Previous](@previous) | [Next](@next)
