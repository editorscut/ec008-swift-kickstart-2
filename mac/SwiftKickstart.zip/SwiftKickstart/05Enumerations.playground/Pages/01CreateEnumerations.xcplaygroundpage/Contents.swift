//: ### Create Enumerations
//: [TOC](00TOC) | Previous | [Next](@next)
enum Color {
    case red
    case green
    case blue
}
let paintBrush: Color
var crayon = Color.red
crayon = .green
paintBrush = .blue
//: [TOC](00TOC) | Previous | [Next](@next)
