//: ### Let
//: [TOC](TOC) | [Previous](@previous) | [Next](@next)
let someone = "Swift Programmer"

let shouldBeRed: Bool
shouldBeRed = true

let stringWithoutValue: String

if shouldBeRed {
    stringWithoutValue = "red"
} else {
    stringWithoutValue = "blue"
}

print(shouldBeRed)

//: [TOC](TOC) | [Previous](@previous) | [Next](@next)
