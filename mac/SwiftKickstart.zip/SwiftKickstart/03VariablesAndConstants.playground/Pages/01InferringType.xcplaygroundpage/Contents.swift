//: ### Inferring Type
//: [TOC](TOC) | Previous | [Next](@next)

let someone = "Swift Programmer"

func hello(peopleNamed people: String...) {
    for person in people {
        print("Hello, \(person)!")
    }
}
//: [TOC](TOC) | Previous | [Next](@next)
