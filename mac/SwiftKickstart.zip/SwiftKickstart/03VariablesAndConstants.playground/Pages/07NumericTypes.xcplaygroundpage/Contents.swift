//: ### Numeric Types
//: [TOC](00TOC) | [Previous](@previous) | [Next](@next)

let literalProduct = 5 * 3.7

let five = 5
let threePointSeven = 3.7

let doubleFiveFromInt = Double(five)

let product = doubleFiveFromInt * threePointSeven

let compactProduct = Double(five) * threePointSeven

//: [TOC](00TOC) | [Previous](@previous) | [Next](@next)

