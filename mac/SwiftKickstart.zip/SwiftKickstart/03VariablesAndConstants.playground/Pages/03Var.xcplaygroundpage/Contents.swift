//: ### Var
//: [TOC](TOC) | [Previous](@previous) | [Next](@next)

var prime = 5
prime = 7

//: [TOC](TOC) | [Previous](@previous) | [Next](@next)
