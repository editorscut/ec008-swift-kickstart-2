//: ### Nil
//: [TOC](TOC) | [Previous](@previous) | [Next](@next)
var name: String?
name = "Swifty"
print(name!)
name = nil
// print(name!) runtime error


//: [TOC](TOC) | [Previous](@previous) | [Next](@next)
