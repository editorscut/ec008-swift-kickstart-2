//: ### Nil Coalescing Operator
//: [TOC](00TOC) | [Previous](@previous) | [Next](@next)

var name: String?
name = "Swifty"

let validName = name ?? "name is nil"

print(validName)

//: [TOC](00TOC) | [Previous](@previous) | [Next](@next)

