public class SettableName {
    public var name: String
    
    public init(name: String) {
        self.name = name
    }
}
