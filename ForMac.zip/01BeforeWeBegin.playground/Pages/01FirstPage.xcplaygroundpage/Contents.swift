//: ### First Page
//: [TOC](TOC) | [Next](@next)

import Cocoa

var str = "Hello, playground"

//: [TOC](TOC) | [Next](@next)