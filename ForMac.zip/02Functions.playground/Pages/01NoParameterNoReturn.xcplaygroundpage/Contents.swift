//: ### No Parameter No Return
//: [TOC](TOC) | Previous | [Next](@next)
func hello() {
    print("Hello, World!")
}
hello()
//: [TOC](TOC) | Previous | [Next](@next)