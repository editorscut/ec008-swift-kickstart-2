var drinkSizes = ["Big", "Really Big", "Enormous"]
var sales = Array(repeating: 0, count: 3)
var numbers = Array(0...5)
