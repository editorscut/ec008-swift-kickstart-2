struct Vertex {
  
}

let point = Vertex()
