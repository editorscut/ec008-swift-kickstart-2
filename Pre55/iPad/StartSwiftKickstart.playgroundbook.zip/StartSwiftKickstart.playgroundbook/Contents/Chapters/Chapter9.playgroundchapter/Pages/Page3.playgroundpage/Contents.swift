extension Forecast {
    static func number(_ index: Int) -> String? {
       
    }
}


//Forecast.number(0)
//Forecast.number(-2)
//Forecast.number(20)
