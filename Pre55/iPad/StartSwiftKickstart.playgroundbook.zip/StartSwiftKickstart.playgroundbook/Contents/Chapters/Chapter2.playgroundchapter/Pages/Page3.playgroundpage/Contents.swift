func hello() -> String {
    "Hello, World!"
}

hello()
