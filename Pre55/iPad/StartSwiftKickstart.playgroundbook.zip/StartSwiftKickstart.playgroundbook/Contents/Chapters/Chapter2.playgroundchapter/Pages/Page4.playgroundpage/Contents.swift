func hello() -> String {
    "Hello, World!"
}

func hello(name: String) -> String {
    "Hello, \(name)!"
}

hello()

hello(name: "my friend")
