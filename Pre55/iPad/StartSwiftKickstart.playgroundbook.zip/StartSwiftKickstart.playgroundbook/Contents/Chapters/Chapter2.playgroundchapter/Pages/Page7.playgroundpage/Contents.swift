func hello(name: String) -> String {
    "Hello, \(name)!"
}
hello(name: "my friend")
