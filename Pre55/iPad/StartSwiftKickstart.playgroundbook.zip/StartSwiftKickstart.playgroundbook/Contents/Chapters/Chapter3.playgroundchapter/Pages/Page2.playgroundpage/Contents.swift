let someone = "Swift Programmer"

