/*:
 # Chapter 5 Enumerations
 * [01 Create Enumerations](01CreateEnumerations)
 * [02 The switch Statement](02TheSwitchStatement)
 * [03 Methods](03Methods)
 * [04 Computed Properties](04ComputedProperties)
 * [05 String Raw Values](05StringRawValues)
 * [06 Numerical Raw Values](06NumericalRawValues)
 * [07 Associated Values](07AssociatedValues)
 * [08 Binding Associated Values](08BindingAssociatedValues)
 * [09 Previews](09Previews)
 * [10 Value Types](10ValueTypes)
 * [11 Option Sets](11OptionSets)
 */
º
