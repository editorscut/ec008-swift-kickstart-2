//: ### Access and Enumerate Dictionaries
//: [TOC](00TOC) | [Previous](@previous) | [Next](@next)
let numbers = ["one":1, "two":2, "three":3]


//: [TOC](00TOC) | [Previous](@previous) | [Next](@next)


