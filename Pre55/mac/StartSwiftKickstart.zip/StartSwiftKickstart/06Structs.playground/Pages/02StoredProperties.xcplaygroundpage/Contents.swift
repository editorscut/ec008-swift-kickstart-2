//: ### Stored Properties
//: [TOC](00TOC) | [Previous](@previous) | [Next](@next)
struct Vertex {
}

let point = Vertex()
//: [TOC](00TOC) | [Previous](@previous) | [Next](@next)
