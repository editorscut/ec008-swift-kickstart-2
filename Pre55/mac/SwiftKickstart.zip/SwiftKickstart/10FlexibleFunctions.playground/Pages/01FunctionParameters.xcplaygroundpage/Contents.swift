//: ### Function Parameters
//: [TOC](00TOC) | Previous | [Next](@next)

var two = 2

func double(_ input: Int) {
  var input = input
  input = input * 2
}

double(two)
two
//: [TOC](00TOC) | Previous | [Next](@next)
