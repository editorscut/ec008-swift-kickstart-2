//: ### Var
//: [TOC](00TOC) | [Previous](@previous) | [Next](@next)
var prime = 5

prime = 7

//prime = 13.0
//: [TOC](00TOC) | [Previous](@previous) | [Next](@next)

