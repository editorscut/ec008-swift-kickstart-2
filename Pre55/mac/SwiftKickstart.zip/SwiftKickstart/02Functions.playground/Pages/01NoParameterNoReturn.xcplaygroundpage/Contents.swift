//: ### No Parameter No Return
//: [TOC](00TOC) | Previous | [Next](@next)

func hello() {
  print("Hello, World!")
}

hello()
//: [TOC](00TOC) | Previous | [Next](@next)
