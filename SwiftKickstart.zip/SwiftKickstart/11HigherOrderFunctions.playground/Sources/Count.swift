public typealias Count = Int

extension Count {
  public var asDouble:  Double {
        return Double(self)
    }
}
