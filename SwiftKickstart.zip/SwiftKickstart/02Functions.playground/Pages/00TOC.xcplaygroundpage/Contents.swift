/*:
 # Chapter 2 Functions
 * [01 No Parameter No Return](01NoParameterNoReturn)
 * [02 Return Values](02ReturnValues)
 * [03 Single Parameter](03SingleParameter)
 * [04 Overloading](04Overloading)
 * [05 Default Values](05DefaultValues)
 * [06 External Parameter Names](06ExternalParameterNames)
 * [07 Multiple Parameters](07MultipleParameters)
 * [08 Variadic Parameters](08VariadicParameters)
 * [09 The print() Function](09ThePrintFunction)
 * [10 Returning Tuples](10ReturningTuples)
 */

