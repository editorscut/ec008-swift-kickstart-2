//: ### Return Values
//: [TOC](00TOC) | [Previous](@previous) | [Next](@next)
func hello() -> String {
  "Hello, World!"
}

hello()
//: [TOC](00TOC) | [Previous](@previous) | [Next](@next)
