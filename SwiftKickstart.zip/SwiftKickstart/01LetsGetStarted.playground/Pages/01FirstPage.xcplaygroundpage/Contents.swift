//: ### First Page
//: [TOC](00TOC) | Previous | [Next](@next)
let hello = "Hello"
print(hello)
//: [TOC](00TOC) | Previous | [Next](@next)

