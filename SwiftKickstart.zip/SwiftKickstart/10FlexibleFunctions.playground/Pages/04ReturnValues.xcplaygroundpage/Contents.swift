//: ### Return Values
//: [TOC](00TOC) | [Previous](@previous) | [Next](@next)
var number = 2
2

func doubled(_ input: Int) -> Int {
  input * 2
}

doubled(number)
doubled(number)
doubled(number)
doubled(number)

number

number = doubled(number)
number
//: [TOC](00TOC) | [Previous](@previous) | [Next](@next)


