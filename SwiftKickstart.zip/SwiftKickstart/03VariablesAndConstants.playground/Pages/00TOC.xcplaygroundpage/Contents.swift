/*:
 # Chapter 3 Variables and Constants
 * [01 Inferring Type](01InferringType)
 * [02 Let](02Let)
 * [03 Var](03Var)
 * [04 Using Variables and Constants](04UsingVariablesAndConstants)
 * [05 Storing Functions](05StoringFunctions)
 * [06 TypeAlias](06TypeAlias)
 * [07 Numeric Types](07NumericTypes)
 * [08 Nil](08Nil)
 * [09 Nil Coalescing Operator](09NilCoalescingOperator)
 * [10 if let](10IfLet)
 */
