//: ### Let
//: [TOC](00TOC) | [Previous](@previous) | [Next](@next)
let someone = "Swift Programmer"

let shouldBeRed: Bool
shouldBeRed = true
print(shouldBeRed)

//let stringWithoutValue
//= if shouldBeRed {
//  "red"
//} else {
//  "blue"
//}

let stringWithoutValue = shouldBeRed ? "red" : "blue"

print(stringWithoutValue)

//: [TOC](00TOC) | [Previous](@previous) | [Next](@next)

