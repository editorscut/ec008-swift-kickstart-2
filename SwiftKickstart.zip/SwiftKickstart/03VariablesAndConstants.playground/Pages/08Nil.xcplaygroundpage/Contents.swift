//: ### Nil
//: [TOC](00TOC) | [Previous](@previous) | [Next](@next)
var name: String?
name = "Swifty"
print(name)
name = nil
print(name)

//: [TOC](00TOC) | [Previous](@previous) | [Next](@next)

