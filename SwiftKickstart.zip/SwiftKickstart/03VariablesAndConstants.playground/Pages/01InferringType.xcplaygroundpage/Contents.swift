//: ### Inferring Type
//: [TOC](00TOC) | Previous | [Next](@next)
let  someone = "Swift Programmer"

func hello(_ people: String...) {
    for person in people {
        print("Hello, \(person)!")
    }
}
//: [TOC](00TOC) | Previous | [Next](@next)

