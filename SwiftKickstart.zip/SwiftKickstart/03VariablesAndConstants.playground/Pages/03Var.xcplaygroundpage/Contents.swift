//: ### Var
//: [TOC](00TOC) | [Previous](@previous) | [Next](@next)
var prime = 5

prime = 7
