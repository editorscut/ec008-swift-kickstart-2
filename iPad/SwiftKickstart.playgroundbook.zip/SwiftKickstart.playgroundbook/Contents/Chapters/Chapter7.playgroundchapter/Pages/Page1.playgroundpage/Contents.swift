class Attendee {
    let name = "Daniel"
    let hometown = "Shaker Heights"
}

let person = Attendee()
person.name
person.hometown
