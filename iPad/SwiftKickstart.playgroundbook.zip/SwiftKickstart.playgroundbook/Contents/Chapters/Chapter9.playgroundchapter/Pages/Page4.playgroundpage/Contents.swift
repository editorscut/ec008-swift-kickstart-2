var number = 2

func doubled(_ input: Int) -> Int {
    return input * 2
}

doubled(number)
number
number = doubled(number)
number
