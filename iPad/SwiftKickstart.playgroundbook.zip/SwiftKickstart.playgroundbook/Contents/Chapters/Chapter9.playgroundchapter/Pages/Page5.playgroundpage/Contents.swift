var number = 2

extension Int {
    func doubled() -> Int {
        return self * 2
    }
}

number = number.doubled()
number
