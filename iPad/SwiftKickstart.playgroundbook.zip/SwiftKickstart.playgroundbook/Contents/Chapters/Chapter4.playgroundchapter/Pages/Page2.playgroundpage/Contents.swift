var drinkSizes = ["Big", "Really Big", "Enormous"]
var sales = Array(repeating: 0, count: 3)
