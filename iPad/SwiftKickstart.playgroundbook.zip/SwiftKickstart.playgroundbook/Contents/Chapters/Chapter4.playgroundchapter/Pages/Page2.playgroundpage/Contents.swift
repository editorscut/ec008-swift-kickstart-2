var drinkSizes = ["Big", "Really Big", "Huge"]
var sales = Array(repeating: 0, count: 3)
