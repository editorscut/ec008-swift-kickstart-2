enum Color: String {
    case red = "Maraschino"
    case green
    case blue = "Blueberry"
}

let crayon = Color.green
crayon.rawValue
let paintBrush = Color.red
paintBrush.rawValue
