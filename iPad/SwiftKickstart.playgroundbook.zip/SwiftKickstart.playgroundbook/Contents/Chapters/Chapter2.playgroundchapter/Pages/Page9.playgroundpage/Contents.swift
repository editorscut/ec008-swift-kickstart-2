let name = "Swift Programmer"
print("Hello, \(name)!")
print("Hello,", name, "!")
print("Hello,", name, "!", separator:"^-^")
print("Hello, ", name, "!", separator: "", terminator: "")
