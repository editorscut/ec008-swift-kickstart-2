func hello() {
    print("Hello, World!")
}
hello()