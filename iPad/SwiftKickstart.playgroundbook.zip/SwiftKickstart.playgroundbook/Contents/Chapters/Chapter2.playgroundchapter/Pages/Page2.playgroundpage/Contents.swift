func hello() -> String {
  print("Just a demonstration")
   return "Hello, World!"
}
hello()
