var name: String?
name = "Swifty"
//name = nil
print(name!)
