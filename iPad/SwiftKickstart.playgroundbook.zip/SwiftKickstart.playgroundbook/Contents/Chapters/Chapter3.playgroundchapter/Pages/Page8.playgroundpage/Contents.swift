var name: String?
name = "Swifty"
print(name!)
name = nil
// print(name!) runtime error
