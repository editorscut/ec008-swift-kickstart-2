var prime = 5
prime = 7
