let literalProduct = 5 * 3.7
let five = 5
let threePointSeven = 3.7
//let fiveCastedToDouble = five as Double
let doubleFiveFromInt = Double(five)
//let impossibleProduct = five * threePointSeven
let product = doubleFiveFromInt * threePointSeven
let compactProduct = Double(five) * threePointSeven
