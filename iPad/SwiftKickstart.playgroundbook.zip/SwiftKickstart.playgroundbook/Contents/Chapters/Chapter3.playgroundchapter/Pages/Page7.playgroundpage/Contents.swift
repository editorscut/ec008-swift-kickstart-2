let literalProduct = 5 * 3.7

let five = 5
let threePointSeven = 3.7

let doubleFiveFromInt = Double(five)

let product = doubleFiveFromInt * threePointSeven

let compactProduct = Double(five) * threePointSeven
