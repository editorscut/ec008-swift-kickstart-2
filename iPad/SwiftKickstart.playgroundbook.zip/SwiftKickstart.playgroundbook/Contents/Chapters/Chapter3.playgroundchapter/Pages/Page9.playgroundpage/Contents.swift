var name: String?
name = "Swifty"

let validName = name ?? "name is nil"

print(validName)
