let someone = "Swift Programmer"

let shouldBeRed: Bool
shouldBeRed = true

let stringWithoutValue: String

if shouldBeRed {
    stringWithoutValue = "red"
} else {
    stringWithoutValue = "blue"
}

print(shouldBeRed)
