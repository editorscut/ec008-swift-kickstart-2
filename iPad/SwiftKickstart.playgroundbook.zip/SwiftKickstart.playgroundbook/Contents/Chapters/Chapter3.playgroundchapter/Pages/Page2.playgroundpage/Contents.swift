let someone = "Swift Programmer"

// someone = "Some new value"

let shouldBeRed: Bool

//print(shouldBeRed)

shouldBeRed = true

let stringWithoutValue: String

if shouldBeRed {
    stringWithoutValue = "red"
} else {
    stringWithoutValue = "blue"
}

print(shouldBeRed)
