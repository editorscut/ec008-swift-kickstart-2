class Attendee {
    var name = "Daniel"
    let hometown = "Shaker Heights"
}
