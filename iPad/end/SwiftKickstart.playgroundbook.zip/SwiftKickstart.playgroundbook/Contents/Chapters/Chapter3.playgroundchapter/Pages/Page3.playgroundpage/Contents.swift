var prime = 5
prime = 7
// prime = "thirteen"
