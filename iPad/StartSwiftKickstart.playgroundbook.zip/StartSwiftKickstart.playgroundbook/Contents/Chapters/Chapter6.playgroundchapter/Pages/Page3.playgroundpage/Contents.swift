struct Vertex {
    let x, y: Double
}

var point = Vertex(x: 3.0, y: 4.0)
