class Attendee {
    var name = "Daniel"
    let hometown = "Shaker Heights"
}

let person1 = Attendee()
person1.name
person1.hometown
