enum Color {
    case red
    case green
    case blue
}
