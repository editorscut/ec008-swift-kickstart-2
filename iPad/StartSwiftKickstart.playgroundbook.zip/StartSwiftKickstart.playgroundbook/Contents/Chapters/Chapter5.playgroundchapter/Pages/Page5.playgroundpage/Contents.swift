enum PrimaryColor {
    case red
    case yellow
    case blue
}
