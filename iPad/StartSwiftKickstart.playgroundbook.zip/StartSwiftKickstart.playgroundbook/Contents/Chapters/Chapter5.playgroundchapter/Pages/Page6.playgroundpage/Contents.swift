enum Color : String {
    case red
    case green
    case blue
}
