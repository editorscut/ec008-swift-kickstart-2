func hello() -> String {
    return "Hello, World!"
}

hello()
