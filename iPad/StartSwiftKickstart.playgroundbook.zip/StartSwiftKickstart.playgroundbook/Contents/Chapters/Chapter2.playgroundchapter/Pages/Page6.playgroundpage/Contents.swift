func hello(name: String = "World") -> String {
    return "Hello, \(name)!"
}

hello()
hello(name: "my friend")
