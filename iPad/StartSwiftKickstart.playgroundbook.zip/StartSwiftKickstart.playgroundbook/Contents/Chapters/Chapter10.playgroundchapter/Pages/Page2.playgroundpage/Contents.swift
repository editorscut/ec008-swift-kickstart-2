class TextField {
    var text = ""
}
