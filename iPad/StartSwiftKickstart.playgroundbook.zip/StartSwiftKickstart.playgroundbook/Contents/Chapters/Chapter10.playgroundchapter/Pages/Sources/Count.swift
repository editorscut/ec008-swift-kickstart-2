public typealias Count = Int

extension Count {
    public func asDouble() -> Double {
        return Double(self)
    }
}
