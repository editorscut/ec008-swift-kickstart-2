public class GettableName {
    public private(set) var name: String
    
    public init(name: String) {
        self.name = name
    }
}
