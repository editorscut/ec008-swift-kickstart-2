let someone = "Swift Programmer"
