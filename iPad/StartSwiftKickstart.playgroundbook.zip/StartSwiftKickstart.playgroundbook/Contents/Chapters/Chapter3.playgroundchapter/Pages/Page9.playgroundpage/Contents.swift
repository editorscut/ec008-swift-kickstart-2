var name: String?
name = "Swifty"

