enum Cardinal: Int {
    case zero
    case one
    case two
    case three
    case four
}

let number = Cardinal.three
