extension Forecast {
    static func number(_ index: Int) -> String {
        Forecast()[index]
    }
}
