func hello(to name: String = "World") {
    print("Hello, \(name)!")
}
hello()
hello(to: "my friend")
